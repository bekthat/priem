from django.forms.widgets import TextInput

#class WeekInput(TextInput):
#   input_type = 'week'